// File: com/example/locationfinder/data/Location.kt

package com.example.locationfinder.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location") // Table name should match the table name in your SQLite database
data class Location(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val address: String,
    val latitude: Double,
    val longitude: Double
)
