// File: com/example/locationfinder/data/LocationDao.kt

package com.example.locationfinder.data

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationDao {
    @Query("SELECT * FROM location")
    fun getAllLocations(): Flow<List<Location>>
}
