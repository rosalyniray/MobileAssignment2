package com.example.locationfinder.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.locationfinder.data.Location
import com.example.locationfinder.repository.LocationRepository
import kotlinx.coroutines.launch

class LocationViewModel(private val repository: LocationRepository) : ViewModel() {

    fun addLocation(location: Location) {
        viewModelScope.launch {
            repository.addLocation(location)
        }
    }

    fun deleteLocation(location: Location) {
        viewModelScope.launch {
            repository.deleteLocation(location)
        }
    }

    fun updateLocation(location: Location) {
        viewModelScope.launch {
            repository.updateLocation(location)
        }
    }

    fun getLocationByAddress(address: String, onResult: (Location?) -> Unit) {
        viewModelScope.launch {
            val location = repository.getLocationByAddress(address)
            onResult(location)
        }
    }
}
