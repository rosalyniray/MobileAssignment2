// File: com/example/locationfinder/ui/MainActivity.kt

package com.example.locationfinder.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.locationfinder.data.Location
import com.example.locationfinder.data.LocationDatabase
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var locationDatabase: LocationDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        locationDatabase = LocationDatabase.getDatabase(this)

        lifecycleScope.launch {
            // Insert a sample location
            locationDatabase.locationDao().insertLocation(
                Location(address = "Sample Address", latitude = 43.65107, longitude = -79.347015)
            )

            // Retrieve all locations
            val locations = locationDatabase.locationDao().getAllLocations()
            // Do something with the retrieved locations (e.g., display them in the UI)
        }
    }
}
