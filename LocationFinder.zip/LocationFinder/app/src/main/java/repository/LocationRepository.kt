package com.example.locationfinder.repository

import com.example.locationfinder.data.Location
import com.example.locationfinder.data.LocationDao

class LocationRepository(private val locationDao: LocationDao) {
    suspend fun addLocation(location: Location) = locationDao.addLocation(location)
    suspend fun deleteLocation(location: Location) = locationDao.deleteLocation(location)
    suspend fun updateLocation(location: Location) = locationDao.updateLocation(location)
    suspend fun getLocationByAddress(address: String) = locationDao.getLocationByAddress(address)
}
